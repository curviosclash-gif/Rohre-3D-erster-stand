# bot_ki

Final exportierbare KI-Konfiguration fuer Kollegen.

## Dateien

- `ai_config.json`: Maschinenlesbare Konfiguration.
- `ai_config.mjs`: ESM-Export fuer Node-Canary und Tooling.
- `ai_config.js`: Kompatibler ESM-Export fuer bestehende Integrationen.

## Herkunft

- Generiert: 2026-02-23T19:23:06.214Z
- Candidate ID: cand-ad3ce95314315f3d
- Seed-Hash: dc268f12a2bd0df0
- Backend: cpu

## Canary

- Runtime Canary: PASS
