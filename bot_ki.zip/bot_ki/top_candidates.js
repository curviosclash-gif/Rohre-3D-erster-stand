export const TOP_CANDIDATES = {
  "generatedAt": "2026-02-23T05:01:51.703Z",
  "sessionId": "20260223T041626_29380",
  "selectedRunTag": "20260223T041626_29380_r01",
  "entries": [
    {
      "rank": 1,
      "runTag": "20260223T041626_29380_r01",
      "status": "PASS",
      "rankScore": 1896.6447604063028,
      "proxyScore": 2913.511074636719,
      "validationScore": 1875.719756270905,
      "holdoutScore": 1896.6447604063028,
      "banditReward": 500,
      "banditRewardSource": "validationScore",
      "bestCandidateId": "cand-ee2614f7eecae052",
      "metrics": {
        "improvementPct": 5.214847107346108,
        "baselineBestScore": 216.16258372089888,
        "newBestScore": 227.43513196523278,
        "avgSurvivalSecImprovementPct": 102.60015183368365,
        "botWinRateImprovementPct": 44.000000000000085,
        "selfCollisionReductionPct": 63.829787234042556,
        "qualityLossPct": 0
      },
      "holdoutMetrics": {
        "improvementPct": 1.4012907486009176,
        "baselineBestScore": 1128.899273089079,
        "newBestScore": 1144.6955908188284,
        "avgSurvivalSecImprovementPct": 51.75465030661831,
        "botWinRateImprovementPct": 46.42857142857143,
        "selfCollisionReductionPct": 20.37037037037036,
        "qualityLossPct": 0
      },
      "holdoutLongWindow": {
        "selectedWindowRounds": 20000,
        "roundsAnalyzed": 20000,
        "sampleCount": 2,
        "sourceMode": "avg-probes",
        "planHash": "1817bb821ecbd2c21b22",
        "avgSurvivalSec": 138.04352523333324,
        "botWinRate": 0.9719519999999935,
        "selfCollisionsPerRound": 1.7995929999998763,
        "meanScore": 691.7223428348846,
        "immediateDangerPct": 0.3220844576919281,
        "stuckFramePct": 0
      },
      "absoluteChampionGate": {
        "pass": true,
        "reason": "absolute-champion-gate-pass",
        "evidence": {
          "selectedWindowRounds": 20000,
          "roundsAnalyzed": 20000,
          "sampleCount": 2,
          "sourceMode": "avg-probes",
          "planHash": "1817bb821ecbd2c21b22",
          "avgSurvivalSec": 138.04352523333324,
          "botWinRate": 0.9719519999999935,
          "selfCollisionsPerRound": 1.7995929999998763,
          "meanScore": 691.7223428348846,
          "immediateDangerPct": 0.3220844576919281,
          "stuckFramePct": 0
        },
        "checks": {
          "longWindowRounds": true,
          "survival": true,
          "winRate": true,
          "objective": true,
          "selfCollisions": true
        },
        "thresholds": {
          "minLongWindowRounds": 20000,
          "minAvgSurvivalSec": 30,
          "stretchTargetAvgSurvivalSec": 600,
          "minBotWinRate": 0.7,
          "maxSelfCollisionsPerRound": null,
          "allowWinRateAlternative": true
        },
        "stretchTargetHit": false
      },
      "preset": "safe-curriculum-a"
    }
  ]
};
export default TOP_CANDIDATES;
